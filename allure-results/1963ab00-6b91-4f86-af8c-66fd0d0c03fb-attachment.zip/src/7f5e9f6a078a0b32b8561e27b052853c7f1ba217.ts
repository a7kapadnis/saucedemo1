import { expect, test } from '@playwright/test';
import { TablePage } from '../pages/TablePage';

test('table page methods can be called sequentially', async ({ page }) => {
    const tablePage = new TablePage(page);

    await tablePage.goto();
    await tablePage.isLoaded();

  //  const rowCount = await tablePage.getRowCount();
    //expect(rowCount).toBeGreaterThan(0);

    //const firstRowData = await tablePage.getRowData(0);
    //await tablePage.validateRowData(firstRowData);

    const allRowData = await tablePage.getAllRowData();
    expect(allRowData).toHaveLength(rowCount);

    for (const rowData of allRowData) {
        await tablePage.validateRowData(rowData);
    }
});
