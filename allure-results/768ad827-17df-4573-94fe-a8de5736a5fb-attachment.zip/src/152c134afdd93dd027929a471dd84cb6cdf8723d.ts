import {test,expect} from '@playwright/test';
import path from 'path';

test('Capture basic screenshot',async({page}) =>
{
    await page.goto("https://www.kapruka.com/");
    await page.screenshot({path:'screenshots/basic1.png'});
    await page.screenshot({path:path.resolve('c:\\framework\\screenshots\\a1.jpg'),fullPage:true});

});
