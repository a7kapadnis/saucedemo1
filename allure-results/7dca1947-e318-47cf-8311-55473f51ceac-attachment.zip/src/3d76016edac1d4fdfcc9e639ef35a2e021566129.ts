import { test } from '@playwright/test';
import loginData from '../test-Data/loginData.json';

import { LoginPage } from '../pages/LoginPage';

test('Login with first user', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(loginData[0].username, loginData[0].password);
});